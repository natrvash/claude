NxA — Intro series (final)
==========================
Six vertical videos, 1080x1920, 30 fps, H.264 + AAC, about -17 LUFS.
Voices + sound effects only — add your music under the voices.

1_Yes-But/        Yes / But versions (YES stays, BUT bar under the struck definition)
2_Regular/        Same videos without the Yes / But signs
3_Ava_voiceover/  Ava's cleaned takes (all takes kept)
COPY.md           Words, definitions, lines, AI narration, colours

Order: 1 Photography · 2 Videography · 3 Navid × Ava · 4 Composition · 5 Styling · 6 Lighting
Source + rebuild: github.com/natrvash/claude (branch claude/admiring-fermi-yypjk7) · nxa/videos/src/dict/
